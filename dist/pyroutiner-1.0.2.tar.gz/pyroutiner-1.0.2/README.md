# Routiner
Routine Generation Algorithm
